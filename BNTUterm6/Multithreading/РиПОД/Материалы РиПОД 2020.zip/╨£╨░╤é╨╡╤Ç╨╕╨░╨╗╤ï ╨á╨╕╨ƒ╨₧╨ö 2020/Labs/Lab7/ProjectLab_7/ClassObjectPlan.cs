﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ProjectLab_7
{
    class ClassObjectPlan
    {
        public int N;
        public int NLast;
        public int Weight;
        public ClassObjectPlan(int n, int last, int weight)
        {
            N = n;
            NLast = last;
            Weight = weight;
        }
    }
}
