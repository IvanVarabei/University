/*#include <list>
class Tree
{
	public:
		int N;
        int Npri;
        bool End;
        int Type;
		list<Tree> list; 
		//List<Tree> list;

};*/