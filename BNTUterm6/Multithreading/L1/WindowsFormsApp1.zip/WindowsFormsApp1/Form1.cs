﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1_Load(sender, e);
        }

        //private void Form1_Load(object sender, EventArgs e)
        //{
        //    int n = 8;
        //    double ca = 0.1;
        //    int ct = 4;
        //    chart1.Series["Series1"].LegendText = "Увеличивается а";
        //    double a = 0;
        //    textBox1.Text = "0-1, step:0.1";
        //    textBox2.Text = "" + n;
        //    textBox3.Text = "" + ca;
        //    textBox4.Text = "" + ct;
        //    for (int i = 0; i <= 10; i++)
        //    {

        //        chart1.Series["Series1"].Points.AddXY(i, Amdal(a, n, ca, ct));
        //        a += 0.1;
        //    }
        //}

        //private void Form1_Load(object sender, EventArgs e)
        //{
        //    double a = 0.5;
        //    int n0 = 1;
        //    int n1 = 8;
        //    double ca = 0.1;
        //    int ct = 4;
        //    chart1.Series["Series1"].LegendText = "Увеличивается n";
        //    textBox1.Text = "" + a;
        //    textBox2.Text = "1-8, step:1";
        //    textBox3.Text = "" + ca;
        //    textBox4.Text = "" + ct;
        //    double caa = 0;
        //    for (int i = n0; i <= n1; i++)
        //    {
        //        chart1.Series["Series1"].Points.AddXY(i, Amdal(a, i, ca, ct));
        //    }
        //}

        private void Form1_Load(object sender, EventArgs e)
        {
            double a = 0.1;
            double n = 8;
            double ca0 = 0;
            double ca1 = 0.05;
            int ct = 4;
            textBox1.Text = "" + a;
            textBox2.Text = "" + n;
            textBox3.Text = "0-0.05, step: 0.005";
            textBox4.Text = "" + ct;
            chart1.Series["Series1"].LegendText = "Увеличивается ca";
            double caa = 0;
            for (int i = 0; i <= 10; i++)
            {
                caa += 0.005;
                chart1.Series["Series1"].Points.AddXY(i, Amdal(a, n, caa, ct));
            }
        }

        //private void Form1_Load(object sender, EventArgs e)
        //{
        //    double a = 0.1;
        //    double n = 8;
        //    double ca = 0.01;
        //    int ct0 = 4;
        //    int ct1 = 16;
        //    textBox1.Text = "" + a;
        //    textBox2.Text = "" + n;
        //    textBox3.Text = "" + ca;
        //    textBox4.Text = "4-16, step: 1";
        //    chart1.Series["Series1"].LegendText = "Увеличивается ct";
        //    for (int i = ct0; i <= ct1; i++)
        //    {
        //        chart1.Series["Series1"].Points.AddXY(i, Amdal(a, n, ca, i));
        //    }
        //}

        double Amdal(double a, double n, double ca, double ct)
        {
            return 1 / (a + ((1 - a) / n) + ca * ct);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
